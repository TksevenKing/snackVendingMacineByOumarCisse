#include<iostream>


using namespace std;


class DropCheck{
	public:
		DropCheck();
		bool productReleased();
};

