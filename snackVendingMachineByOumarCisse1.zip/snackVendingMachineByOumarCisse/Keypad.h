#include<iostream>
#include<string>

using namespace std;



class Keypad{
    public:
    	int getSelection();

};


